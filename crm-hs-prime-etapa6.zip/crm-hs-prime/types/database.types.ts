/**
 * Tipos TypeScript espelhando o schema do Supabase (supabase/migrations).
 *
 * Escritos manualmente nesta etapa inicial. Quando o Supabase CLI estiver
 * configurado localmente, recomenda-se substituir este arquivo pelo
 * gerado automaticamente com:
 *
 *   supabase gen types typescript --project-id <ID> > types/database.types.ts
 */

export type Role = 'vendedor' | 'gestor';
export type UserStatus = 'ativo' | 'inativo';
export type LeadStage = 'lead' | 'qualificado' | 'vendido' | 'perdido';
export type Probability = 'baixa' | 'média' | 'alta';

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          role: Role;
          status: UserStatus;
          phone: string | null;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          role?: Role;
          status?: UserStatus;
          phone?: string | null;
          avatar_url?: string | null;
        };
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>;
      };
      leads: {
        Row: {
          id: string;
          name: string;
          whatsapp: string | null;
          car_interest: string | null;
          origin: string | null;
          stage: LeadStage;
          assigned_to: string | null;
          entry_date: string;
          last_contact_date: string | null;
          next_action: string | null;
          next_action_date: string | null;
          probability: Probability | null;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          whatsapp?: string | null;
          car_interest?: string | null;
          origin?: string | null;
          stage?: LeadStage;
          assigned_to?: string | null;
          entry_date?: string;
          last_contact_date?: string | null;
          next_action?: string | null;
          next_action_date?: string | null;
          probability?: Probability | null;
          notes?: string | null;
        };
        Update: Partial<Database['public']['Tables']['leads']['Insert']>;
      };
      lead_history: {
        Row: {
          id: string;
          lead_id: string;
          event_date: string;
          description: string;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          lead_id: string;
          event_date?: string;
          description: string;
          created_by?: string | null;
        };
        Update: Partial<Database['public']['Tables']['lead_history']['Insert']>;
      };
      lead_actions: {
        Row: {
          id: string;
          lead_id: string;
          description: string;
          due_date: string | null;
          completed: boolean;
          completed_at: string | null;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          lead_id: string;
          description: string;
          due_date?: string | null;
          completed?: boolean;
          completed_at?: string | null;
          created_by?: string | null;
        };
        Update: Partial<Database['public']['Tables']['lead_actions']['Insert']>;
      };
      sales: {
        Row: {
          id: string;
          lead_id: string | null;
          seller_id: string | null;
          vehicle: string;
          sale_value: number;
          sale_date: string;
          origin: 'HS PRIME' | 'LOJA PARCEIRA' | null;
          commission_value: number | null;
          payment_method: string | null;
          down_payment: number | null;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          lead_id?: string | null;
          seller_id?: string | null;
          vehicle: string;
          sale_value: number;
          sale_date?: string;
          origin?: 'HS PRIME' | 'LOJA PARCEIRA' | null;
          commission_value?: number | null;
          payment_method?: string | null;
          down_payment?: number | null;
          notes?: string | null;
        };
        Update: Partial<Database['public']['Tables']['sales']['Insert']>;
      };
      commission_settings: {
        Row: {
          id: string;
          car_origin: 'HS PRIME' | 'LOJA PARCEIRA';
          commission_value: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          car_origin: 'HS PRIME' | 'LOJA PARCEIRA';
          commission_value: number;
        };
        Update: Partial<Database['public']['Tables']['commission_settings']['Insert']>;
      };
      loss_reasons: {
        Row: {
          id: string;
          lead_id: string;
          reason: string;
          details: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          lead_id: string;
          reason: string;
          details?: string | null;
        };
        Update: Partial<Database['public']['Tables']['loss_reasons']['Insert']>;
      };
    };
  };
}
