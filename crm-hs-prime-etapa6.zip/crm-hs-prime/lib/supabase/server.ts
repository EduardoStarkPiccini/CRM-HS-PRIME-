import { cookies } from 'next/headers';
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import type { Database } from '@/types/database.types';
import { env } from '@/lib/env';

/**
 * Cliente Supabase para uso em Server Components, Route Handlers e
 * Server Actions. Ainda usa a chave "anon" (respeitando RLS) — a
 * diferença é que aqui ele lê/grava a sessão via cookies do Next.js.
 *
 * Login/autenticação completos entram na próxima etapa do projeto;
 * esta função já deixa o encanamento pronto para quando isso acontecer.
 */
export function createServerSupabaseClient() {
  const cookieStore = cookies();

  return createServerClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL(),
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY(),
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {
            // chamado a partir de um Server Component sem permissão de escrita;
            // seguro ignorar quando há um middleware cuidando da sessão.
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: '', ...options });
          } catch {
            // ver comentário acima
          }
        },
      },
    }
  );
}
