import { NextResponse, type NextRequest } from 'next/server';
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { MOTIVOS_PERDA, STAGE_KEYS, STAGE_LABEL } from '@/lib/leads/constants';

export const runtime = 'nodejs';

/**
 * PATCH /api/leads/:id
 * Atualiza um lead (dados gerais, mudança de etapa, próxima ação).
 * Continua usando o cliente da sessão — se o lead não pertencer ao
 * vendedor que está chamando, o RLS simplesmente não encontra/atualiza
 * a linha, e devolvemos 404 (não vazamos se o lead existe ou não).
 *
 * Se a etapa for alterada, registra automaticamente no lead_history.
 * Se a nova etapa for "perdido", exige o motivo e grava em loss_reasons.
 */
export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const supabase = createServerSupabaseClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 });

  const { id } = params;
  const body = await request.json();

  const { data: existing } = await supabase.from('leads').select('stage').eq('id', id).single();
  if (!existing) {
    return NextResponse.json({ error: 'Lead não encontrado ou sem permissão.' }, { status: 404 });
  }

  const update: Record<string, unknown> = {};
  const fields = [
    'name', 'whatsapp', 'car_interest', 'origin', 'assigned_to',
    'next_action', 'next_action_date', 'notes', 'entry_date', 'probability',
  ];
  for (const f of fields) {
    if (body[f] !== undefined) update[f] = body[f] || null;
  }

  let novaEtapa: string | undefined;
  if (body.stage !== undefined && body.stage !== existing.stage) {
    if (!STAGE_KEYS.includes(body.stage)) {
      return NextResponse.json({ error: 'Etapa inválida.' }, { status: 400 });
    }
    if (body.stage === 'perdido') {
      if (!body.motivoPerda || !MOTIVOS_PERDA.includes(body.motivoPerda)) {
        return NextResponse.json({ error: 'Selecione o motivo da perda.' }, { status: 400 });
      }
    }
    novaEtapa = body.stage;
    update.stage = body.stage;
  }

  if (Object.keys(update).length === 0) {
    return NextResponse.json({ error: 'Nada para atualizar.' }, { status: 400 });
  }

  const { data: lead, error } = await supabase
    .from('leads')
    .update(update)
    .eq('id', id)
    .select()
    .single();

  if (error || !lead) {
    return NextResponse.json({ error: error?.message ?? 'Não foi possível atualizar o lead.' }, { status: 400 });
  }

  if (novaEtapa) {
    await supabase.from('lead_history').insert({
      lead_id: id,
      description: `Movido para ${STAGE_LABEL[novaEtapa]}`,
      created_by: user.id,
    });
    if (novaEtapa === 'perdido') {
      await supabase.from('loss_reasons').insert({
        lead_id: id,
        reason: body.motivoPerda,
        details: body.motivoDetalhes || null,
      });
      await supabase.from('lead_history').insert({
        lead_id: id,
        description: `Motivo da perda: ${body.motivoPerda}`,
        created_by: user.id,
      });
    }
  }

  return NextResponse.json({ ok: true, lead });
}
